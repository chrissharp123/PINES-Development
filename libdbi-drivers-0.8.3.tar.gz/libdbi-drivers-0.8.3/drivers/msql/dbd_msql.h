
#define MSQL_RESERVED_WORDS { \
   NULL }







